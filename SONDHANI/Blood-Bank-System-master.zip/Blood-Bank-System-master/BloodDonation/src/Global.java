
import javax.swing.JFrame;


public class Global 
{
    public static JFrame mainForm;
    public static JFrame currentForm;
    
}
